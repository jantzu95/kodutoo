from airflow import DAG
from airflow.operators.python import PythonOperator
import pendulum
import psutil
import smtplib
from email.mime.text import MIMEText

# Parameetrid
MEMORY_THRESHOLD = 10  # Protsentides
EMAIL_TO = "lipjanar@gmail.com"
EMAIL_FROM = "your-email@example.com"
SMTP_SERVER = "smtp.example.com"  # Muuda oma serveri järgi
SMTP_PORT = 587
SMTP_USER = "your-email@example.com"
SMTP_PASSWORD = "your-email-password"

def check_memory(ti):
    mem = psutil.virtual_memory()
    usage = mem.percent
    print(f"Current memory usage: {usage}%")

    if usage > MEMORY_THRESHOLD:
        print(f"⚠️ Warning: Memory usage is high! {usage}%")
        ti.xcom_push(key='memory_usage', value=usage)
        send_alert_email(usage)

def send_alert_email(usage):
    subject = f"⚠️ High Memory Usage Alert: {usage}%"
    body = f"Warning! System memory usage exceeded {MEMORY_THRESHOLD}%. Current usage: {usage}%."

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = EMAIL_FROM
    msg["To"] = EMAIL_TO

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.sendmail(EMAIL_FROM, EMAIL_TO, msg.as_string())
        server.quit()
        print("✅ Email alert sent successfully!")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")

# Airflow DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': pendulum.today('UTC').add(days=-1),
    'retries': 1,
}

dag = DAG(
    'memory_usage_dag',
    default_args=default_args,
    schedule_interval='*/5 * * * *',  # Jookseb iga 5 minuti tagant
    catchup=False,
)

task = PythonOperator(
    task_id='check_memory',
    python_callable=check_memory,
    dag=dag,
)

task
